
function navbar(){

  return `
     
    <div id="fimg"> <img src="https://scontent-bom1-2.xx.fbcdn.net/v/t1.6435-9/s526x395/75233877_110055893748252_3113452291433168896_n.jpg?_nc_cat=108&ccb=1-5&_nc_sid=09cbfe&_nc_ohc=S4c_g4XqHuoAX959ndV&_nc_oc=AQnyC4tq1pjPkLliKtUfEPZnLVAzCYhu-Lx_o2T5gxHwMf_gAzTaSt6_2EnOQaGJ0SDVH8z_VFBMlH6qqoFqJJ1X&_nc_ht=scontent-bom1-2.xx&oh=00_AT9oVWqHtbTlJ5Ezyf61cHXS8wf2GqaB47TyY1jQhvx2Kg&oe=61FB3ACA" alt=""></div>
    <div id="firstmain">
      <div id="first">
          <img id="home" src="http://www.ranklogos.com/wp-content/uploads/2014/12/Zee-Khana-Khazana-Logo-500x180.jpg" alt="">
          <input type="text" placeholder="Search Receipes" id="search">
          <button id="button">Search</button>
      </div>
      <div id="p">
         
     <div>
        <img id="specialrecipe" src="https://icon-library.com/images/recipe-icon-png/recipe-icon-png-8.jpg" alt="">
 
     </div>
<div>
          
  <img id="latestrecipi" src="https://icon-library.com/images/recipe-icon-png/recipe-icon-png-7.jpg" alt="">
 
</div>
  <div id="signup">
      <img id="signimg" src="https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcQrRwDK0m2hcuGLbuSFxekR1wwvotI7LEAOUa2FCnRWgZUSyix4RAbB5EBh_MycECHuPVI&usqp=CAU" alt="">
  <p id="username">Sign in</p>
  </div>
</div> `


}

function popop(){
return  `
`

}

 export {navbar,popop} 