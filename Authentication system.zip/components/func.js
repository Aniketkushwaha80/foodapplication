function click(){
return `document.querySelector("#specialrecipe").addEventListener("click",special)
function special(){
    window.location.href="special.html"
}

document.querySelector("#latestrecipi").addEventListener("click",latest)
function latest(){
    window.location.href="latest.html"
}`
}
export default click